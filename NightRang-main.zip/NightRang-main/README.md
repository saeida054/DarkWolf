***

# <p align="center" style="color: #000040;" > اوامر التنصيب السورس ↓
```
git clone https://github.com/Yosef-lbban/NightRang ;cd NightRang;chmod +x NightRang ; ./NightRang
```

```
